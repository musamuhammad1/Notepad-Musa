﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyNotepad {
    public static class CONST {
        public const string CannotFindMessage = "Cannot find \"{SearchText}\"";
    }
}
